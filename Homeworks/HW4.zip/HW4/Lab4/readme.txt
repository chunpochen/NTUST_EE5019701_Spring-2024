----------------------------------------------------------------------------
There are some c++ source files in this directory,
analyse their dependencies and write a Makefile including the following rules to 
compile these files; you must compile each source file(.c/.cpp) to object file(.o) first, 
then link them together to produce the executable.

required rules for makefile:

app:  create the executable file
clean: delete executable and all intermediate files (.obj, .o)