----------------------------------------------------------------------------
Based on your work in Lab5, write a Makefile for your program, including the following build rules:

1. fib:      //produce the executable
2. clean:    //delete the executatble and any intermidiate files.
3. test:	 //test the fib program with inputs 1,2,3,...,10, you may need to write a loop within Makefile.

Feel free to test your Makefile.