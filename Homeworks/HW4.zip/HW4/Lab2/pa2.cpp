#include "dijkstra.h"

using namespace std;

struct Net
{
public:
    Net() {}
    int Xs;
	int Ys;
	int Xf;
	int Yf;
    vector<int> path;	// 4 numbers in a group
};


int main(int argc, char **argv)
{
    if(argc != 3)
    {
        cout << "Usage: ./pa2 [input_case] [output_case]" << endl;
        exit(EXIT_FAILURE);
    }

    //=============================================
    //============ Parse the input file ===========
    //=============================================
    fstream inFile;
    inFile.open(argv[1], fstream::in);
    if(!inFile.is_open())
    {
        cout << "The input file is not opened!" << endl;
        exit(EXIT_FAILURE);
    }

    char buffer[100];
    int boundaryX, boundaryY;
    int capacity;
    int num_net;
    vector<Net> net;

    while(inFile >> buffer)
    {
        if(strcmp(buffer, "grid") == 0)
        {
            inFile >> buffer;
            boundaryX = atoi(buffer);
            inFile >> buffer;
            boundaryY = atoi(buffer);
            cout << "grid" << ' ' << boundaryX << ' ' << boundaryY << endl;
        }
        else if(strcmp(buffer, "capacity") == 0)
        {
            inFile >> buffer;
            capacity = atoi(buffer);
            cout << "capacity" << ' ' << capacity << endl;
        }
        else if(strcmp(buffer, "num") == 0)
        {
        	inFile >> buffer;
        	if(strcmp(buffer, "net") == 0)
        	{
        		inFile >> buffer;
        		num_net = atoi(buffer);
        		net.resize(num_net);
        		cout << "num net" << ' ' << num_net << endl;
        	}
        }
        else if( atoi(buffer) >= 0)
        {
        	int i = atoi(buffer);
            inFile >> buffer;
            net[i].Xs = atoi(buffer);
            inFile >> buffer;
            net[i].Ys = atoi(buffer);
            inFile >> buffer;
            net[i].Xf = atoi(buffer);
            inFile >> buffer;
            net[i].Yf = atoi(buffer);
            //cout << i << ' ' << net[i].Xs << ' ' << net[i].Ys << ' ' << net[i].Xf << ' ' << net[i].Yf << endl;
        }
        else
        {
            cout << "Unmatched string in the input file!" << endl;
        }
    }
    

    //=============================================
    //========== Begin Dijkstra Algorithm =========
    //=============================================
    Dijkstra dijkstra(boundaryX, boundaryY, capacity);
    fstream outFile;
    outFile.open(argv[2], fstream::out);
    
    for (int i = 0; i < net.size(); ++i)
    {
    	dijkstra.set_src_tgt(net[i].Xs, net[i].Ys, net[i].Xf, net[i].Yf);
    	net[i].path = dijkstra.routing();
    	dijkstra.clear_all_path();
        
        int num_of_route = net[i].path[0];
        cout << i << ' ' << num_of_route / 4 << endl;
        outFile << i << ' ' << num_of_route / 4 << endl;
        
        while (num_of_route != 0)
        {
            outFile << net[i].path[num_of_route--] << ' ';
            if ((num_of_route % 4) == 0)    outFile << endl;
        }
    }
    
    dijkstra.printEdgeWeights(false, true);
}

