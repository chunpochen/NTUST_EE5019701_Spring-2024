#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cfloat>
#include <cstring>
#include <vector>
#include <iomanip>
#include <list>
#include <queue>
#include <math.h>

using namespace std;

class Grid
{
public:
    // constructor
    Grid()
    {
        _d = DBL_MAX; // #include<cfloat>
        _pi = NULL;
        _isPath = false;
        _isDone = false;  
    }

    // public member functions
    int getX() { return _x; }
    int getY() { return _y; }
    bool isPath() { return _isPath; }
    bool isDone() { return _isDone; }
    double getD() { return _d; }
    Grid *getPi() { return _pi; }

    void setX(int x) { _x = x; }
    void setY(int y) { _y = y; }
    void setPath() { _isPath = true; }
    void setDone() { _isDone = true; }
    void setD(double d) { _d = d; }
    void setPi(Grid *pi) { _pi = pi; }
    void clear()
    {
        _d = DBL_MAX; // #include<cfloat>
        _pi = NULL;
        _isPath = false;
        _isDone = false;  
    }

private:
    // data members
    int _x, _y; // x & y coordinates
    int _demand;
    double _weight;
    bool _isPath;
    bool _isDone; 
    double _d;
    Grid *_pi;
};


class Dijkstra
{
public:
    // constructor
    Dijkstra(int boundx, int boundy, int capacity);
    ~Dijkstra() {}
    
    // functions
    void printMap(bool m, bool d, bool p);
    void printEdgeWeights(bool edge, bool dmnd);
    void relax(Grid *u, Grid *v, const double w);
    Grid *extractMin();
    vector<int> routing();      // return the result
    void clear_all_path();
    void set_src_tgt(const int Xs, const int Ys, const int Xf, const int Yf);
    void updateWeight(const int x1, const int y1, const int x2, const int y2);

    // variable
    double _capacity;
    int _boundaryX;
    int _boundaryY;
    int sourceX, sourceY;
    int targetX, targetY;
    vector< vector<Grid> > map;
    list<Grid *> priorityQ;
    vector< vector<double> > horizontalEdge;
    vector< vector<double> > verticalEdge;
    vector< vector<int> > horizontalDemand;
    vector< vector<int> > verticalDemand;
};