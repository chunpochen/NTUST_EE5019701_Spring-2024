#include "dijkstra.h"

Dijkstra::Dijkstra(int boundx, int boundy, int capacity) : _boundaryX(boundx), _boundaryY(boundy), _capacity(capacity)
{
    horizontalEdge.resize(_boundaryX, vector<double>(_boundaryY-1, 0.00001));
    verticalEdge.resize(_boundaryX-1, vector<double>(_boundaryY, 0.00001));
    horizontalDemand.resize(_boundaryX, vector<int>(_boundaryY-1, 0));
    verticalDemand.resize(_boundaryX-1, vector<int>(_boundaryY, 0));

    /* initialize the routing map */
    map.resize(_boundaryX);
    for(int i = 0; i < _boundaryX; ++i)
    {
        map[i].resize(_boundaryY);
    }

    for(int i = 0; i < _boundaryX; ++i)
    {
        for(int j = 0; j < _boundaryY; ++j)
        {
            map[i][j].setX(i);
            map[i][j].setY(j);
        }
    }
}

vector<int> Dijkstra::routing()
{
	//cout << "source:" << sourceX << ' ' << sourceY << endl;
	//cout << "target:" << targetX << ' ' << targetY << endl;
    /* Push all the grid into the prio. queue*/
    for(int i = 0; i < _boundaryX; ++i)
    {
        for(int j = 0; j < _boundaryY; ++j)
        {
            priorityQ.push_back(&map[i][j]);
        }
    }

    map[sourceX][sourceY].setD(0.00);
    Grid *g;
    while(!priorityQ.empty())
    {
        g = extractMin();
        int currentX=g->getX(), currentY=g->getY();
        double currentD = g->getD();
        /* Relax near by 4 edges of the current point */
        if (currentX - 1 >= 0)
            relax(&map[currentX][currentY], &map[currentX - 1][currentY], verticalEdge[currentX - 1][currentY]);
        if (currentY - 1 >= 0)
            relax(&map[currentX][currentY], &map[currentX][currentY - 1], horizontalEdge[currentX][currentY - 1]);
        if (currentX + 1 < _boundaryX)
            relax(&map[currentX][currentY], &map[currentX + 1][currentY], verticalEdge[currentX][currentY]);
        if (currentY + 1 < _boundaryY)
            relax(&map[currentX][currentY], &map[currentX][currentY + 1], horizontalEdge[currentX][currentY]);
        /* Break when reach the target */
        if (g == &map[targetX][targetY])
            break;
    }
    
    /* Construct the Path */
    vector<int> result(8 * (_boundaryX+_boundaryY));
    int num_of_route = 0;
    while (g != &map[sourceX][sourceY])
    {
    	int x1 = g->getX();
    	int y1 = g->getY();
        result[++num_of_route] = y1;
        result[++num_of_route] = x1;

        g->setPath();
        g = g->getPi();

        int x2 = g->getX();
    	int y2 = g->getY();
        result[++num_of_route] = y2;
        result[++num_of_route] = x2;

        updateWeight(x1, y1, x2, y2);
    }
    //printMap(true, true, true);
    //printEdgeWeights(true, false);
    result[0] = num_of_route;   // First element will store num_of_route
    return result;
}

void Dijkstra::relax(Grid *u, Grid *v, const double w)
{
    if (v->getD() > u->getD() + w)
    {
        v->setD(u->getD() + w);
        v->setPi(u);
    }
}


Grid *Dijkstra::extractMin()
{
    Grid *g;
    list<Grid *>::iterator min_it = priorityQ.begin();
    for(list<Grid *>::iterator it = priorityQ.begin(); it != priorityQ.end(); ++it)
    {
        if((*min_it)->getD() > (*it)->getD())
            min_it = it;
    }
    g = (*min_it);
    (*min_it)->setDone();
    priorityQ.erase(min_it);
    return g;
}


void Dijkstra::clear_all_path()
{
    sourceX = 0, sourceY = 0;
    targetX = 0, targetY = 0;
    priorityQ.clear();

    for(int i = 0; i < _boundaryX; ++i)
    {
        for(int j = 0; j < _boundaryY; ++j)
        {
            map[i][j].clear();
        }
    }
}

void Dijkstra::set_src_tgt(const int Xs, const int Ys, const int Xf, const int Yf)
{
    sourceX = Xs, sourceY = Ys;
    targetX = Xf, targetY = Yf;
    map[sourceX][sourceY].setPath();
    map[targetX][targetY].setPath();
    map[sourceX][sourceY].setD(0.00);
}

void Dijkstra::updateWeight(const int x1, const int y1, const int x2, const int y2)
{
    if (x1 < x2)        // up
    	verticalEdge[x1][y1] = pow(100, (++verticalDemand[x1][y1] / _capacity)) - 1;
    else if (x1 > x2)	// down
    	verticalEdge[x1-1][y1] = pow(100, (++verticalDemand[x1-1][y1] / _capacity)) - 1;
    else if (y1 < y2)	// left
    	horizontalEdge[x1][y1] = pow(100, (++horizontalDemand[x1][y1] / _capacity)) - 1;
    else if (y1 > y2)	// right
    	horizontalEdge[x1][y1-1] = pow(100, (++horizontalDemand[x1][y1-1] / _capacity)) - 1;
}

void Dijkstra::printMap(bool m, bool d, bool p)
{
	if(m)
	{
		cout << "Routing map:" << endl;
	    for(int i = 0; i < map.size(); ++i)
	    {
	        for(int j = 0; j < map[0].size(); ++j)
	        {
	            if(map[i][j].isPath())
	                cout << setw(2) << "*";
	            else
	                cout << setw(2) << "-";
	        }
	        cout << endl;
	    }
	}
    
    if(d)
    {
    	cout << "d map:" << endl;
	    for(int i = 0; i < map.size(); ++i)
	    {
	        for(int j = 0; j < map[0].size(); ++j)
	        {
	            if(map[i][j].getD() == DBL_MAX)
	                cout << setw(6) << "-";
	            else
	                cout << setw(6) << setprecision(2) << map[i][j].getD();
	        }
	        cout << endl;
	    }
    }
    
    if(p)
    {
    	cout << "pi map:" << endl;
	    for(int i = 0; i < map.size(); ++i)
	    {
	        for(int j = 0; j < map[0].size(); ++j)
	        {
	            if(map[i][j].getPi() == NULL)
	                cout << "- ";
	            else
	            {
	                Grid *current = &map[i][j];
	                Grid *pi = map[i][j].getPi();
	                if(pi->getX() < current->getX())
	                    cout << "u ";
	                else if(pi->getX() > current->getX())
	                    cout << "d ";
	                else if(pi->getY() < current->getY())
	                    cout << "l ";
	                else
	                    cout << "r ";
	            }
	        }
	        cout << endl;
	    }
    }
    
}

void Dijkstra::printEdgeWeights(bool edge, bool dmnd)
{
    
	if(edge)
	{
		cout << "Horizontal edge weigths:" << endl;
	    for(int i = 0; i < horizontalEdge.size(); ++i)
	    {
	        for(int j = 0; j < horizontalEdge[0].size(); ++j)
	        {
	            cout << setprecision(2) << fixed << horizontalEdge[i][j] << " ";
	        }
	        cout << endl;
	    }
        
        cout << "Vertical edge weigths:" << endl;
	    for(int i = 0; i < verticalEdge.size(); ++i)
	    {
	        for(int j = 0; j < verticalEdge[0].size(); ++j)
	        {
	            cout << setprecision(2) << fixed << verticalEdge[i][j] << " ";
	        }
	        cout << endl;
	    }
	}
    if(dmnd)
    {
        int overflow = 0;
        cout << "Horizontal demand:" << endl;
	    for(int i = 0; i < horizontalDemand.size(); ++i)
	    {
	        for(int j = 0; j < horizontalDemand[0].size(); ++j)
	        {
	            cout << setprecision(3) << fixed << horizontalDemand[i][j] << " ";
                if (horizontalDemand[i][j] > _capacity) overflow++;
	        }
	        cout << endl;
	    }
        
        cout << "Vertical demand:" << endl;
	    for(int i = 0; i < verticalDemand.size(); ++i)
	    {
	        for(int j = 0; j < verticalDemand[0].size(); ++j)
	        {
	            cout << setprecision(3) << fixed << verticalDemand[i][j] << " ";
                if (verticalDemand[i][j] > _capacity) overflow++;
	        }
	        cout << endl;
	    }
        cout << "Estimate overflow is " << overflow << endl;
    }
}
