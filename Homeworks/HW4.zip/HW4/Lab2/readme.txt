----------------------------------------------------------------------------
There are some source files in this directory.
Execute the Makefile, then execute the rule "clean",

Observe their behaviors and describe them in a file named "answer.txt"