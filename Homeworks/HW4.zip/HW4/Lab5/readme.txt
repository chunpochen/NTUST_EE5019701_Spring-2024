----------------------------------------------------------------------------
Write a c++ program that accept one parameter (command line argument), N,
that computes and print the Nth Fibonacci number.
Compile your program with g++, name the executable "fib".
Ensure that it can be executed by typing

./app <N>

for example
./app 10




