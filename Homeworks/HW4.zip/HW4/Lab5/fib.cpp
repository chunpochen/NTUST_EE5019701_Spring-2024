#include<iostream>
using namespace std;


int factorial(int n) {
	if(n == 1)
		return 0;
	else if(n == 2)
		return 1;
	else
		return factorial(n-1) + factorial(n-2);
}

int main() {
	int n;
	cout << "Enter: ";
	cin >> n;
	cout << n << ": " << factorial(n) << endl;
	return 0;
}
