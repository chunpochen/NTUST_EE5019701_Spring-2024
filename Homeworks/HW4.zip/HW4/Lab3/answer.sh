#!/bin/bash
g++ factorial.cpp hello.cpp main.cpp -o app
./app.exe
echo "Done"
