----------------------------------------------------------------------------

there are some c++ source files in this directory,
compile them with g++ and produce a executable file named "app"

-----------------------
put your solution(the commands you used) into a file named "answer.sh" in this directory,
