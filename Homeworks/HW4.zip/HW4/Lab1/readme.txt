----------------------------------------------------------------------------
install g++ (if not already installed)
Then find out the location of "g++" executable.
-----------------------
put your solution(the commands you used) into a file named "answer.sh" in this directory,
