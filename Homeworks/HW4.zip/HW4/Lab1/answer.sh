#!/bin/bash
location=$(which g++)
echo "g++ is located at: $location"
