Design a shell script that can find all prime numbers in a specified range. 
A prime number is a number that is not divisible by any other positive integers 
except 1 and itself.

Task requirements:
1. The user is prompted to enter two positive integers as the starting range and 
   ending range for prime number search.
2. Design a function that checks whether a number is prime.
3. Iterates through each number in the specified range and calls the prime number 
   check function on each number.
4. If a number is prime, print it.