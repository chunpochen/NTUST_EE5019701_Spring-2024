#!/bin/bash
log_file="$(pwd)/access.log"
echo "Log file contents:"
cat "$log_file"
