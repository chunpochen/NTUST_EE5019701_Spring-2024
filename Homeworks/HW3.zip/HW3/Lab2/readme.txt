There is a file named "access.log" in the 
current directory. Print its contents.

put your solution(the commands you used) into a file named "answer.sh" in this directory