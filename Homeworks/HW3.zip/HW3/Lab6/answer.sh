#!/bin/bash

find . -type f -name "*.o" -delete

