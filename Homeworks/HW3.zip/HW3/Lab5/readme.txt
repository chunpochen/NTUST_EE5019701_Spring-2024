There's a folder named "foo" in this directory,
copy all of its content, recursively, to another folder named "bar",
Create that folder if you have to.

put your solution(the commands you used) into a file named "answer.sh" in this directory