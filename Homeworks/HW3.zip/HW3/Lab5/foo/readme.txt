There are files in this folder with different file extensions.
Remove all files with the .o extension, recursively, 
from the current working directory and all sub directory.

put your solution(the commands you used) into a file named "answer.sh" in this directory