/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOKINT = 258,
     TOKSTRING = 259,
     IDENTIFIER = 260,
     INTEGER = 261,
     STRING = 262,
     BOOLEAN = 263,
     REAL = 264,
     CONST = 265,
     LOCAL = 266,
     FUNCTION = 267,
     PRINT = 268,
     PRINTLN = 269,
     READ = 270,
     RETURN = 271,
     IF = 272,
     END = 273,
     WHILE = 274,
     FOR = 275,
     DO = 276,
     ELSE = 277,
     THEN = 278,
     REPEAT = 279,
     UNTIL = 280,
     TRUE = 281,
     FALSE = 282,
     NIL = 283,
     IMPORT = 284,
     IN = 285,
     OR = 286,
     AND = 287,
     NOT = 288,
     EQ = 289,
     NE = 290,
     LE = 291,
     GE = 292
   };
#endif
/* Tokens.  */
#define TOKINT 258
#define TOKSTRING 259
#define IDENTIFIER 260
#define INTEGER 261
#define STRING 262
#define BOOLEAN 263
#define REAL 264
#define CONST 265
#define LOCAL 266
#define FUNCTION 267
#define PRINT 268
#define PRINTLN 269
#define READ 270
#define RETURN 271
#define IF 272
#define END 273
#define WHILE 274
#define FOR 275
#define DO 276
#define ELSE 277
#define THEN 278
#define REPEAT 279
#define UNTIL 280
#define TRUE 281
#define FALSE 282
#define NIL 283
#define IMPORT 284
#define IN 285
#define OR 286
#define AND 287
#define NOT 288
#define EQ 289
#define NE 290
#define LE 291
#define GE 292




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 11 "lua.y"
{
    int int_value;
    char* string_value;
    int symboltype;
    FuncRec* fmeta;
}
/* Line 1529 of yacc.c.  */
#line 130 "y.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

