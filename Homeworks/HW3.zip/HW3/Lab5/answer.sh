#!/bin/bash

if [ -d "foo" ]; then
	if [ ! -d "bar" ]; then
		mkdir bar
	fi

	cp -r foo/* bar/
	echo "Success"
else
	echo "failure"

fi	
