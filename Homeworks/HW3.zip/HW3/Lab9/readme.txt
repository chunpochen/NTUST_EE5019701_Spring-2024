
There is a file named message.txt, view its content and write it down below.
-----------------------
your answer:
-----------------------