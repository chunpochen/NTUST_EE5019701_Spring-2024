#!/bin/bash
cat message.txt
content=$(cat message.txt)
awk 'NR==3{$0=$0 "  '"$content"'"} 1' readme.txt > temp && mv temp readme.txt
