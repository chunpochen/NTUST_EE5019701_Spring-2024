print the current working directory.

put your solution(the commands you used) into a file named "answer.sh" in this directory