#!/bin/sh
echo "$BASH_SOURCE"

