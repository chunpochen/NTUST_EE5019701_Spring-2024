#!/bin/bash

if [ -e "access.log" ]; then
	grep "Accepted" access.log
else
	echo "Error"
fi
