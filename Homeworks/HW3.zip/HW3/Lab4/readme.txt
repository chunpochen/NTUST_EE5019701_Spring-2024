There is a file named "access.log" in the current working directory. Print all lines
in this file that contains the string "Accepted"

put your solution(the commands you used) into a file named "answer.sh" in this directory