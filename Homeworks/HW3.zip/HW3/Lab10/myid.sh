#!/bin/bash


echo '#!/bin/bash' > myid.sh
echo 'echo "Your Student ID: 1234567890"' >> myid.sh  
chmod +x myid.sh

mkdir -p ~/bin

ln -sf $(pwd)/myid.sh ~/bin/myid

if [[ ":$PATH:" != *":$HOME/bin:"* ]]; then
    echo 'export PATH=$PATH:~/bin' >> ~/.bashrc
    source ~/.bashrc
fi