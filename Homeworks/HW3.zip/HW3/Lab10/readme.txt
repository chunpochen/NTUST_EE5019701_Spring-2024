----------------------------------------------------------------------------

Create a shell script named "myid.sh" that prints your student id,
add this script to $PATH via one of the following method:

1. Add current directory to $PATH
2. link
so it can be called as though it were a command.

輸入 "myid" 即可列印出 "Student ID: M11207521"