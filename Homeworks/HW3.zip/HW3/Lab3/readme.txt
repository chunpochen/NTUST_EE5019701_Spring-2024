There is a file named "access.log" in the current working directory. 
Print the last 5 lines of "access.log".


put your solution(the commands you used) into a file named "answer.sh" in this directory