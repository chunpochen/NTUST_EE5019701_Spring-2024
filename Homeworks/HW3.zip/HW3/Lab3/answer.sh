#!/bin/bash
fileName="$(pwd)/access.log"
tail -4 "$fileName"
