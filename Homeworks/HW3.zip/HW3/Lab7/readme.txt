Create 2000 empty subdirectories in this directory, the names of these directories are not restricted.
For example Lab7/dir1, Lab7/dir2, ..., Lab7/dir2000.
Restrict read/write permission of these directories for everyone except yourself(so only you can access them).

put your solution(the commands you used) into a file named "answer.sh" in this directory