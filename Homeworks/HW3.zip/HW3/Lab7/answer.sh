#!/bin/bash
for dir in Lab7/dir{1..2000}; do
	mkdir -p "$dir"
	chmod 700 "$dir"
done

