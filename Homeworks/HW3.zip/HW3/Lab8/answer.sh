#!/bin/bash

for file in *.c; do
	if [ -f "$file" ]; then
		mv "$file" "${file%.c}.cpp"
		echo "Success"
	fi
done
