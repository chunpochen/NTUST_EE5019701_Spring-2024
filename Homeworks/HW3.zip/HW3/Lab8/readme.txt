Rename every file within this directory that ends with .c to .cpp, 
for example, asm.c should be renamed to asm.cpp.


put your solution(the commands you used) into a file named "answer.sh" in this directory